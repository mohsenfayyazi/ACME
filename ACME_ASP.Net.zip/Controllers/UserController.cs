﻿using Microsoft.AspNet.Identity.Owin;
using System.Data.Entity;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace ACMEProject.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        private ApplicationUserManager _userManager;

        [RequireHttps]
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult logoutPage()
        {
            return View();
        }



        public ActionResult Profile()
        {
            int Id = int.Parse( Session["UserID"].ToString());
            using (MyDatabaseEntities dc = new MyDatabaseEntities())
            {
                var Userp = dc.Users.Find(Id);//.Users.Where(xx => xx.UserID == Id).FirstOrDefault();
                return View(Userp);
            }

            
        }
        public ActionResult EditProfile(User U)
        {

            
            using (MyDatabaseEntities dc = new MyDatabaseEntities())
            {

                dc.Entry(U).State = EntityState.Modified;
                dc.SaveChanges();
               
                ViewBag.Message = "Registration is done Successfully";
            }

            return RedirectToAction("Profile", "User");
        }
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }
        public ActionResult Logout()
        {
            Session["UserInfo"] = null;
            Session.Abandon();
           
            return RedirectToAction("logoutPage", "User");
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async System.Threading.Tasks.Task<ActionResult> Register(User U)
        {
            if (ModelState.IsValid)
            {
                using (MyDatabaseEntities dc = new MyDatabaseEntities())
                {
                    U.Password = Membership.GeneratePassword(12, 1);
                    dc.Users.Add(U);
                    dc.SaveChanges();
                    ModelState.Clear();
                    
                    ViewBag.Message = "Registration is done Successfully";

                    //*****************************  Code for Sending Email and Password
                            //SmtpClient smtpClient = new SmtpClient("mail.MyWebsiteDomainName.com", 25);

                            //smtpClient.Credentials = new System.Net.NetworkCredential("info@MyWebsiteDomainName.com", "myIDPassword");
                            //    smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                            //smtpClient.EnableSsl = true;
                            //MailMessage mail = new MailMessage();

                            ////Setting From , To and CC
                            //mail.From = new MailAddress("info@MyWebsiteDomainName", "New Password");
                            //mail.To.Add(new MailAddress(U.EmailID));
                            //mail.Body="Your Password is : " + U.Password;
                   

                            //smtpClient.Send(mail);
                    //***********************************************************************
                    U = null;
                }
            }
            return View(U);
        }


    }
}